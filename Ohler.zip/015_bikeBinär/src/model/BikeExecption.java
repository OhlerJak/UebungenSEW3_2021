package model;

public class BikeExecption extends Exception {
  public BikeExecption(String message) {
    super(message);
  }
}
