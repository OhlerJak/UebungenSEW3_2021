package csvoutput;

public class CSVOutputException extends Exception{

    public CSVOutputException(String mes){
        super(mes);
    }
}
